package com.poolaim.lab;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0F1722"));
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("Compass");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Start the bubble, open your pool game, then tap the 8 bubble to open the aim table on top of the game.");
        hint.setTextColor(Color.parseColor("#9FB3C8"));
        hint.setTextSize(15);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 24, 0, 32);
        root.addView(hint);

        Button start = new Button(this);
        start.setText("Start floating bubble");
        start.setOnClickListener(v -> startBubble());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop bubble");
        stop.setOnClickListener(v -> stopService(new Intent(this, BubbleService.class)));
        root.addView(stop);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    private void startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then press Start again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        startForegroundService(new Intent(this, BubbleService.class));
        moveTaskToBack(true);
    }
}
