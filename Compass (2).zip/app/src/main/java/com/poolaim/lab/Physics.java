package com.poolaim.lab;

import java.util.ArrayList;
import java.util.List;

/**
 * Ball physics measured from a screen recording of the game.
 * All coordinates are in "table units": the playing felt is 932 wide and 466 high,
 * the ball radius is 14. The constants below were fitted to real shots.
 */
public final class Physics {

    public static final float W = 932f, H = 466f, R = 14f, INSET = 17f;

    // fitted from your video: friction a = A0 + K * max(0, v - THR)   (units/s^2)
    static final float A0 = 41.2f, K = 0.263f, THR = 124f;
    static final float E_WALL = 0.524f;   // speed kept after a cushion
    static final float E_BALL = 0.96f;    // ball-to-ball bounce

    // x, y, mouth radius (cushions switch off), pot radius
    static final float[][] PK = {
            {-17, -17, 52, 30}, {949, -17, 52, 30},
            {-17, 483, 52, 30}, {949, 483, 52, 30},
            {466, -25, 54, 28}, {466, 491, 54, 28}
    };

    public static final class Body {
        public float x, y, vx, vy;
        public int type;              // 0 cue, 1 black, 2 solid, 3 stripe
        public boolean out;
        public int pocket = -1;
        public float startX, startY;
        public final ArrayList<float[]> path = new ArrayList<>();
    }

    public static final class Out {
        public final ArrayList<Body> bodies = new ArrayList<>();
        public boolean cuePot, blackPot;
        public int othersPotted;
        public int firstType = -1;    // type of the first ball the cue ball touches, -1 = nothing
        public float hitX, hitY;
        public float seconds;
        public final ArrayList<float[]> ray = new ArrayList<>();
    }

    /** launch speed for a given power number (points = cue points x pull) */
    public static float speedFor(float power) {
        float c = 0.44f + 0.116f * Math.min(1f, Math.max(0f, (power - 150f) / 2850f));
        return c * power;
    }

    /**
     * balls: each entry {x, y, type}; cueIdx = index of the cue ball; (dx,dy) = unit aim direction.
     */
    public static Out run(List<float[]> balls, int cueIdx, float dx, float dy, float power) {
        return run(balls, cueIdx, dx, dy, power, 14f);
    }

    public static Out run(List<float[]> balls, int cueIdx, float dx, float dy, float power, float maxSeconds) {
        Out o = new Out();
        for (float[] b : balls) {
            Body k = new Body();
            k.x = b[0];
            k.y = b[1];
            k.startX = k.x;
            k.startY = k.y;
            k.type = (int) b[2];
            k.path.add(new float[]{k.x, k.y});
            o.bodies.add(k);
        }
        Body cue = o.bodies.get(cueIdx);
        float v0 = speedFor(power);
        cue.vx = dx * v0;
        cue.vy = dy * v0;

        final float dt = 1f / 500f;
        final int maxSteps = (int) (maxSeconds / dt);
        final int n = o.bodies.size();
        boolean hitDone = false;
        int step;
        for (step = 0; step < maxSteps; step++) {
            boolean moving = false;
            for (Body b : o.bodies) {
                if (b.out) continue;
                float s = (float) Math.sqrt(b.vx * b.vx + b.vy * b.vy);
                if (s > 0f) {
                    float dec = (A0 + K * Math.max(0f, s - THR)) * dt;
                    float s2 = s - dec;
                    if (s2 < 2f) {
                        b.vx = 0f;
                        b.vy = 0f;
                    } else {
                        b.vx *= s2 / s;
                        b.vy *= s2 / s;
                        b.x += b.vx * dt;
                        b.y += b.vy * dt;
                        moving = true;
                    }
                }
            }
            // pockets and cushions
            for (Body b : o.bodies) {
                if (b.out) continue;
                boolean mouth = false;
                for (int p = 0; p < PK.length; p++) {
                    float ddx = b.x - PK[p][0], ddy = b.y - PK[p][1];
                    float d2 = ddx * ddx + ddy * ddy;
                    if (d2 < PK[p][3] * PK[p][3]) {
                        b.out = true;
                        b.pocket = p;
                        b.vx = 0f;
                        b.vy = 0f;
                        b.path.add(new float[]{PK[p][0], PK[p][1]});
                        if (b.type == 0) o.cuePot = true;
                        else if (b.type == 1) o.blackPot = true;
                        else o.othersPotted++;
                        break;
                    }
                    if (d2 < PK[p][2] * PK[p][2]) mouth = true;
                }
                if (b.out) continue;
                float lo = mouth ? INSET - 30f : INSET;
                float hiX = mouth ? W - INSET + 30f : W - INSET;
                float hiY = mouth ? H - INSET + 30f : H - INSET;
                if (b.x < lo) {
                    b.x = 2 * lo - b.x;
                    b.vx = -b.vx * E_WALL;
                    b.vy *= E_WALL;
                } else if (b.x > hiX) {
                    b.x = 2 * hiX - b.x;
                    b.vx = -b.vx * E_WALL;
                    b.vy *= E_WALL;
                }
                if (b.y < lo) {
                    b.y = 2 * lo - b.y;
                    b.vy = -b.vy * E_WALL;
                    b.vx *= E_WALL;
                } else if (b.y > hiY) {
                    b.y = 2 * hiY - b.y;
                    b.vy = -b.vy * E_WALL;
                    b.vx *= E_WALL;
                }
            }
            // ball to ball
            for (int i = 0; i < n; i++) {
                Body a = o.bodies.get(i);
                if (a.out) continue;
                for (int j = i + 1; j < n; j++) {
                    Body b = o.bodies.get(j);
                    if (b.out) continue;
                    float ddx = b.x - a.x, ddy = b.y - a.y;
                    float d2 = ddx * ddx + ddy * ddy;
                    if (d2 >= 4 * R * R || d2 == 0f) continue;
                    float d = (float) Math.sqrt(d2);
                    float nx = ddx / d, ny = ddy / d;
                    float ov = (2 * R - d) / 2f;
                    a.x -= nx * ov;
                    a.y -= ny * ov;
                    b.x += nx * ov;
                    b.y += ny * ov;
                    float vn = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
                    if (vn <= 0f) continue;
                    if (!hitDone && (a == cue || b == cue)) {
                        hitDone = true;
                        Body other = (a == cue) ? b : a;
                        o.firstType = other.type;
                        o.hitX = cue.x;
                        o.hitY = cue.y;
                    }
                    float jn = (1f + E_BALL) / 2f * vn;
                    a.vx -= jn * nx;
                    a.vy -= jn * ny;
                    b.vx += jn * nx;
                    b.vy += jn * ny;
                    moving = true;
                }
            }
            if (step % 4 == 0) {
                for (Body b : o.bodies) {
                    if (!b.out && (b.vx != 0f || b.vy != 0f)) b.path.add(new float[]{b.x, b.y});
                }
            }
            if (!moving) break;
        }
        o.seconds = step * dt;
        for (Body b : o.bodies) {
            if (!b.out) b.path.add(new float[]{b.x, b.y});
        }
        buildRay(o, cue, dx, dy);
        return o;
    }

    /** Straight "infinite" aim ray with cushion bounces, stopping when it meets a ball. */
    private static void buildRay(Out o, Body cue, float dx, float dy) {
        float x = cue.startX, y = cue.startY;
        o.ray.add(new float[]{x, y});
        for (int seg = 0; seg < 8; seg++) {
            float t = 1e9f;
            if (dx > 0f) t = Math.min(t, (W - INSET - x) / dx);
            else if (dx < 0f) t = Math.min(t, (INSET - x) / dx);
            if (dy > 0f) t = Math.min(t, (H - INSET - y) / dy);
            else if (dy < 0f) t = Math.min(t, (INSET - y) / dy);
            // nearest ball on this segment
            float hitT = t;
            boolean hit = false;
            for (Body b : o.bodies) {
                if (b == cue) continue;
                float ex = b.startX - x, ey = b.startY - y;
                float proj = ex * dx + ey * dy;
                if (proj <= 0f) continue;
                float perp2 = ex * ex + ey * ey - proj * proj;
                if (perp2 >= 4 * R * R) continue;
                float tt = proj - (float) Math.sqrt(4 * R * R - perp2);
                if (tt > 0f && tt < hitT) {
                    hitT = tt;
                    hit = true;
                }
            }
            x += dx * hitT;
            y += dy * hitT;
            o.ray.add(new float[]{x, y});
            if (hit) break;
            if (x <= INSET + 0.01f || x >= W - INSET - 0.01f) dx = -dx;
            if (y <= INSET + 0.01f || y >= H - INSET - 0.01f) dy = -dy;
        }
    }
}
