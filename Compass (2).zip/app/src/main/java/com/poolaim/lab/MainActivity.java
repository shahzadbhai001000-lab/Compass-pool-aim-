package com.poolaim.lab;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 100;
    private EditText power;
    private CheckBox extreme, ray;
    private RadioGroup target;
    private SharedPreferences sp;

    private TextView label(String s, int size, int color, int top) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, top, 0, 0);
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0F1722"));
        root.setPadding(48, 48, 48, 48);

        TextView title = label("Compass", 28, Color.WHITE, 0);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        root.addView(label(
                "1. Press Start and allow the permissions.\n"
                        + "2. Open your game. Compass is live: while the balls are still, it finds the best "
                        + "shot by itself and draws it in green. You do not need to aim first.\n"
                        + "3. If you also aim in the game, it shows where your aim goes and warns when the "
                        + "cue ball or black ball will pot.\n"
                        + "4. Tap the N bubble to turn live assist off or on (green ring = on). "
                        + "Hold the bubble to cycle the pull power: 100, 75, 50, 25 percent.",
                14, Color.parseColor("#9FB3C8"), 24));

        root.addView(label("Cue power points (7714 = your level 5 cue)", 14, Color.WHITE, 32));
        power = new EditText(this);
        power.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        power.setText(String.valueOf(sp.getInt("power", 7714)));
        power.setTextColor(Color.WHITE);
        root.addView(power);

        root.addView(label("Which balls are yours?", 14, Color.WHITE, 24));
        target = new RadioGroup(this);
        String[] names = {"Any ball", "Solids", "Stripes"};
        int cur = sp.getInt("target", 0);
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setTextColor(Color.WHITE);
            rb.setId(1000 + i);
            target.addView(rb);
            if (i == cur) rb.setChecked(true);
        }
        root.addView(target);

        extreme = new CheckBox(this);
        extreme.setText("Extreme: show every ball's path and stop point");
        extreme.setTextColor(Color.WHITE);
        extreme.setChecked(sp.getBoolean("extreme", true));
        root.addView(extreme);

        ray = new CheckBox(this);
        ray.setText("Infinite aim ray with cushion bounces");
        ray.setTextColor(Color.WHITE);
        ray.setChecked(sp.getBoolean("ray", true));
        root.addView(ray);

        Button start = new Button(this);
        start.setText("Start Compass");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop Compass");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, BubbleService.class));
            }
        });
        root.addView(stop);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    private void save() {
        int p = 7714;
        try {
            p = Integer.parseInt(power.getText().toString().trim());
        } catch (Exception ignored) {
        }
        if (p < 100) p = 100;
        if (p > 30000) p = 30000;
        int t = Math.max(0, Math.min(2, target.getCheckedRadioButtonId() - 1000));
        sp.edit().putInt("power", p)
                .putInt("target", t)
                .putBoolean("extreme", extreme.isChecked())
                .putBoolean("ray", ray.isChecked())
                .apply();
    }

    private void start() {
        save();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then press Start again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent s = new Intent(this, BubbleService.class);
                s.putExtra("code", res);
                s.putExtra("data", data);
                startForegroundService(s);
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Screen capture permission is needed to read the table", Toast.LENGTH_LONG).show();
            }
        }
    }
}
