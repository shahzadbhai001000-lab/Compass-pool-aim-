package com.poolaim.lab;

import java.util.ArrayList;
import java.util.List;

/** Finds the best shot on the table without needing any aim from the player. */
public final class Advisor {

    public static final class Shot {
        public boolean found;
        public boolean bank;      // object ball bounces off one cushion before the pocket
        public float dx, dy, pull, score;
        public float cx, cy;      // cue ball start
        public float gx, gy;      // where the cue ball touches the target (the "ghost ball")
        public float tx, ty;      // target ball
        public float bx, by;      // cushion bounce point (bank shots only)
        public float px, py;      // pocket
        public int target = -1;
        public Physics.Out out;
    }

    /** mode: 0 any ball, 1 solids, 2 stripes */
    private static boolean eligible(int type, int mode, boolean blackOk) {
        if (type == 1) return blackOk;
        if (type == 2) return mode != 2;
        if (type == 3) return mode != 1;
        return false;
    }

    private static float segDist(float ax, float ay, float bx, float by, float px, float py) {
        float vx = bx - ax, vy = by - ay;
        float l2 = vx * vx + vy * vy;
        float t = l2 == 0f ? 0f : ((px - ax) * vx + (py - ay) * vy) / l2;
        if (t < 0f) t = 0f;
        else if (t > 1f) t = 1f;
        float qx = ax + vx * t - px, qy = ay + vy * t - py;
        return (float) Math.sqrt(qx * qx + qy * qy);
    }

    private static boolean clear(float ax, float ay, float bx, float by, List<float[]> balls, int skipA, int skipB) {
        for (int i = 0; i < balls.size(); i++) {
            if (i == skipA || i == skipB) continue;
            float[] b = balls.get(i);
            if (segDist(ax, ay, bx, by, b[0], b[1]) < 2f * Physics.R * 0.95f) return false;
        }
        return true;
    }

    private static void addCandidate(ArrayList<Shot> cands, ArrayList<Float> geo, List<float[]> balls,
                                     int cueIdx, int ti, float aimX, float aimY,
                                     float bounceX, float bounceY, boolean bank, float px, float py) {
        float[] c = balls.get(cueIdx);
        float[] t = balls.get(ti);
        float ux = aimX - t[0], uy = aimY - t[1];
        float ul = (float) Math.sqrt(ux * ux + uy * uy);
        if (ul < 1f) return;
        ux /= ul;
        uy /= ul;
        float gx = t[0] - ux * 2f * Physics.R, gy = t[1] - uy * 2f * Physics.R;
        if (gx < Physics.INSET - 4 || gx > Physics.W - Physics.INSET + 4
                || gy < Physics.INSET - 4 || gy > Physics.H - Physics.INSET + 4) return;
        float ax = gx - c[0], ay = gy - c[1];
        float al = (float) Math.sqrt(ax * ax + ay * ay);
        if (al < 4f) return;
        ax /= al;
        ay /= al;
        float cut = ax * ux + ay * uy;
        if (cut < 0.3f) return;
        if (!clear(c[0], c[1], gx, gy, balls, cueIdx, ti)) return;
        if (bank) {
            if (!clear(t[0], t[1], bounceX, bounceY, balls, cueIdx, ti)) return;
            if (!clear(bounceX, bounceY, px, py, balls, cueIdx, ti)) return;
        } else {
            if (!clear(t[0], t[1], px, py, balls, cueIdx, ti)) return;
        }
        Shot s = new Shot();
        s.dx = ax;
        s.dy = ay;
        s.cx = c[0];
        s.cy = c[1];
        s.gx = gx;
        s.gy = gy;
        s.tx = t[0];
        s.ty = t[1];
        s.px = px;
        s.py = py;
        s.bx = bounceX;
        s.by = bounceY;
        s.bank = bank;
        s.target = ti;
        cands.add(s);
        geo.add(cut * 2f - (al + ul) / 1000f - (bank ? 0.6f : 0f));
    }

    public static Shot best(List<float[]> balls, int cueIdx, int mode, float fullPower) {
        Shot best = new Shot();
        float[] c = balls.get(cueIdx);
        int left = 0;
        for (float[] b : balls) {
            int t = (int) b[2];
            if (t == 2 && mode != 2) left++;
            if (t == 3 && mode != 1) left++;
        }
        final boolean blackOk = left == 0;
        final float lo = Physics.INSET, hiX = Physics.W - Physics.INSET, hiY = Physics.H - Physics.INSET;
        final float edge = 40f;   // keep bounce points away from the pockets

        ArrayList<Shot> cands = new ArrayList<>();
        ArrayList<Float> geo = new ArrayList<>();
        for (int i = 0; i < balls.size(); i++) {
            if (i == cueIdx) continue;
            float[] t = balls.get(i);
            if (!eligible((int) t[2], mode, blackOk)) continue;
            for (int p = 0; p < Physics.PK.length; p++) {
                float px = Physics.PK[p][0], py = Physics.PK[p][1];
                // straight pot
                addCandidate(cands, geo, balls, cueIdx, i, px, py, 0f, 0f, false, px, py);
                // one-cushion banks: mirror the pocket across each cushion
                for (int side = 0; side < 4; side++) {
                    float mx = px, my = py;
                    if (side == 0) mx = 2f * lo - px;
                    else if (side == 1) mx = 2f * hiX - px;
                    else if (side == 2) my = 2f * lo - py;
                    else my = 2f * hiY - py;
                    float vx = mx - t[0], vy = my - t[1];
                    float k;
                    float bx, by;
                    if (side < 2) {
                        float plane = side == 0 ? lo : hiX;
                        if (Math.abs(vx) < 1e-3f) continue;
                        k = (plane - t[0]) / vx;
                        if (k <= 0f || k >= 1f) continue;
                        bx = plane;
                        by = t[1] + vy * k;
                        if (by < lo + edge || by > hiY - edge) continue;
                    } else {
                        float plane = side == 2 ? lo : hiY;
                        if (Math.abs(vy) < 1e-3f) continue;
                        k = (plane - t[1]) / vy;
                        if (k <= 0f || k >= 1f) continue;
                        by = plane;
                        bx = t[0] + vx * k;
                        if (bx < lo + edge || bx > hiX - edge) continue;
                    }
                    addCandidate(cands, geo, balls, cueIdx, i, bx, by, bx, by, true, px, py);
                }
            }
        }
        // keep the most promising candidates by geometry
        ArrayList<Shot> top = new ArrayList<>();
        for (int k = 0; k < 14 && !cands.isEmpty(); k++) {
            int bi = 0;
            for (int i = 1; i < cands.size(); i++) if (geo.get(i) > geo.get(bi)) bi = i;
            top.add(cands.remove(bi));
            geo.remove(bi);
        }

        final float[] pulls = {0.45f, 0.7f, 1.0f};
        final float[] offs = {0f, 0.0087f, -0.0087f};   // 0 and +-0.5 degrees
        float bestScore = -1e9f;
        for (Shot s0 : top) {
            for (float off : offs) {
                float co = (float) Math.cos(off), si = (float) Math.sin(off);
                Shot s = copy(s0);
                s.dx = s0.dx * co - s0.dy * si;
                s.dy = s0.dx * si + s0.dy * co;
                for (float pull : pulls) {
                    Physics.Out o = Physics.run(balls, cueIdx, s.dx, s.dy, fullPower * pull, 8f);
                    float sc = 0f;
                    if (o.cuePot) sc -= 1000f;
                    if (o.blackPot) sc += blackOk ? 300f : -2000f;
                    for (Physics.Body b : o.bodies) {
                        if (!b.out) continue;
                        if (b.type == 2 || b.type == 3) sc += eligible(b.type, mode, blackOk) ? 100f : -40f;
                    }
                    if (o.bodies.get(s.target).out) sc += 60f;
                    if (o.firstType < 0) sc -= 500f;
                    else if (!eligible(o.firstType, mode, blackOk)) sc -= 200f;
                    sc -= pull * 20f;
                    if (s0.bank) sc -= 15f;   // prefer a straight pot when both work
                    if (sc > bestScore) {
                        bestScore = sc;
                        best = copy(s);
                        best.pull = pull;
                        best.score = sc;
                        best.out = o;
                    }
                }
            }
        }
        best.found = bestScore > 0f && best.out != null && best.target >= 0
                && best.out.bodies.get(best.target).out && !best.out.cuePot;
        return best;
    }

    private static Shot copy(Shot s) {
        Shot n = new Shot();
        n.dx = s.dx;
        n.dy = s.dy;
        n.cx = s.cx;
        n.cy = s.cy;
        n.gx = s.gx;
        n.gy = s.gy;
        n.tx = s.tx;
        n.ty = s.ty;
        n.px = s.px;
        n.py = s.py;
        n.bx = s.bx;
        n.by = s.by;
        n.bank = s.bank;
        n.target = s.target;
        return n;
    }
}
