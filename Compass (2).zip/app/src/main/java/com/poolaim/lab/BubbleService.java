package com.poolaim.lab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;

public class BubbleService extends Service {

    private static final String CHANNEL = "compass_bubble";
    private static final int[] PULLS = {100, 75, 50, 25};

    private WindowManager wm;
    private TextView bubble;
    private GradientDrawable bubbleBg;
    private AimOverlay overlay;
    private WindowManager.LayoutParams bubbleLp;
    private MediaProjection mp;
    private ImageReader reader;
    private VirtualDisplay vd;
    private int sw, sh;
    private final Handler h = new Handler(Looper.getMainLooper());

    private volatile boolean want = false;
    private volatile boolean busy = false;
    private volatile boolean live = false;
    private volatile boolean needHide = false;   // set when capture can see our own overlay
    private volatile int bubbleX, bubbleY, bubbleSize;
    private long lastToast = 0;

    // state used only by the analysis thread
    private float[][] prev = null;
    private long lastKey = 0;
    private Advisor.Shot lastBest = null;

    private final Runnable tickRun = new Runnable() {
        @Override
        public void run() {
            tick();
        }
    };
    private final Runnable timeoutRun = new Runnable() {
        @Override
        public void run() {
            if (want) {
                want = false;
                finishTick(400);
            }
        }
    };
    private final Runnable armRun = new Runnable() {
        @Override
        public void run() {
            want = true;
            h.postDelayed(timeoutRun, 2500);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        if (in == null || !in.hasExtra("data")) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (mp == null) {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            Intent data = in.getParcelableExtra("data");
            int code = in.getIntExtra("code", 0);
            mp = m.getMediaProjection(code, data);
            if (mp == null) {
                stopSelf();
                return START_NOT_STICKY;
            }
            mp.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            stopSelf();
                        }
                    });
                }
            }, h);
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            createOverlay();
            createBubble();
            setLive(true);
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Compass bubble", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Compass")
                .setContentText("Live aim assist is running")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi)
                .build();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String m) {
        long now = System.currentTimeMillis();
        if (now - lastToast < 5000) return;
        lastToast = now;
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------ views

    private void createOverlay() {
        overlay = new AimOverlay(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(overlay, lp);
    }

    private void createBubble() {
        bubble = new TextView(this);
        bubble.setText("N");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(20);
        bubble.setTypeface(null, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColor(0xE0222222);
        bubbleBg.setStroke(dp(3), 0xFFE08A2C);
        bubble.setBackground(bubbleBg);

        int size = dp(52);
        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(4);
        bubbleLp.y = dp(90);
        bubbleX = bubbleLp.x;
        bubbleY = bubbleLp.y;
        bubbleSize = size;

        final boolean[] longFired = {false};
        final Runnable longPress = new Runnable() {
            @Override
            public void run() {
                longFired[0] = true;
                cyclePull();
            }
        };
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float downX, downY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        moved = false;
                        longFired[0] = false;
                        h.postDelayed(longPress, 700);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                            h.removeCallbacks(longPress);
                        }
                        if (moved) {
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = startY + (int) dy;
                            bubbleX = bubbleLp.x;
                            bubbleY = bubbleLp.y;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        h.removeCallbacks(longPress);
                        if (!moved && !longFired[0] && e.getAction() == MotionEvent.ACTION_UP) setLive(!live);
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);
    }

    private void cyclePull() {
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        int cur = sp.getInt("pull", 100);
        int next = PULLS[0];
        for (int i = 0; i < PULLS.length; i++) {
            if (PULLS[i] == cur) next = PULLS[(i + 1) % PULLS.length];
        }
        sp.edit().putInt("pull", next).apply();
        Toast.makeText(this, "Pull power " + next + "%", Toast.LENGTH_SHORT).show();
    }

    private void setLive(boolean on) {
        live = on;
        if (bubbleBg != null) bubbleBg.setStroke(dp(3), on ? 0xFF00E676 : 0xFFE08A2C);
        h.removeCallbacks(tickRun);
        if (on) {
            Toast.makeText(this, "Live aim assist ON", Toast.LENGTH_SHORT).show();
            h.post(tickRun);
        } else {
            overlay.clear();
            Toast.makeText(this, "Live aim assist OFF", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------ live loop

    private void tick() {
        if (!live) return;
        if (busy) {
            h.postDelayed(tickRun, 150);
            return;
        }
        busy = true;
        try {
            ensureDisplay();
        } catch (Throwable t) {
            busy = false;
            live = false;
            Toast.makeText(this, "Screen capture failed: " + t.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        if (needHide) {
            overlay.setVisibility(View.INVISIBLE);
            h.postDelayed(armRun, 130);
        } else {
            armRun.run();
        }
    }

    private void finishTick(long delay) {
        busy = false;
        want = false;
        h.removeCallbacks(timeoutRun);
        if (overlay != null) overlay.setVisibility(View.VISIBLE);
        if (live) h.postDelayed(tickRun, delay);
    }

    private void ensureDisplay() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels, hh = dm.heightPixels;
        if (vd != null && w == sw && hh == sh) return;
        if (vd != null) vd.release();
        if (reader != null) reader.close();
        sw = w;
        sh = hh;
        reader = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                onFrame(r);
            }
        }, h);
        vd = mp.createVirtualDisplay("compass", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);
    }

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            if (!want) return;
            want = false;
            h.removeCallbacks(timeoutRun);
            final int w = img.getWidth(), hh = img.getHeight();
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int ps = pl.getPixelStride(), rs = pl.getRowStride();
            Bitmap bm = Bitmap.createBitmap(rs / ps, hh, Bitmap.Config.ARGB_8888);
            bm.copyPixelsFromBuffer(buf);
            final int[] pix = new int[w * hh];
            bm.getPixels(pix, 0, w, 0, 0, w, hh);
            bm.recycle();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    process(pix, w, hh);
                }
            }).start();
        } catch (Throwable t) {
            want = false;
            finishTick(1000);
        } finally {
            if (img != null) img.close();
        }
    }

    // ------------------------------------------------------------ analysis

    private static boolean isMarker(int[] pix, int w) {
        int hits = 0;
        for (int i = 0; i < 4; i++) {
            int p = pix[(10 + i * 6) * w + (10 + i * 6)];
            int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            if (r > 220 && b > 220 && g < 60) hits++;
        }
        return hits >= 3;
    }

    private void postDone(final Physics.Out aim, final Advisor.Shot best, final float ox, final float oy,
                          final float sc, final boolean ext, final boolean ray, final boolean clear) {
        h.post(new Runnable() {
            @Override
            public void run() {
                if (live) {
                    if (clear) overlay.clear();
                    else overlay.show(aim, best, ox, oy, sc, ext, ray);
                }
                finishTick(clear ? 120 : 100);
            }
        });
    }

    private void process(int[] pix, int w, int hh) {
        try {
            if (isMarker(pix, w)) {
                // capture can see our own overlay: hide it while capturing from now on
                needHide = true;
                postDone(null, null, 0, 0, 1, false, false, true);
                return;
            }
            int[] f = Detector.findFelt(pix, w, hh);
            if (f == null) {
                prev = null;
                postDone(null, null, 0, 0, 1, false, false, true);
                return;
            }
            int fw = f[2] - f[0], fh = f[3] - f[1];
            int[] crop = new int[fw * fh];
            for (int y = 0; y < fh; y++) System.arraycopy(pix, (f[1] + y) * w + f[0], crop, y * fw, fw);
            final float sc = fw / Physics.W;
            Detector.Result res = Detector.detect(crop, fw, fh, Physics.R * sc, 55f);

            // ignore anything under our own bubble
            float rad = Physics.R * sc;
            Iterator<Detector.Ball> it = res.balls.iterator();
            while (it.hasNext()) {
                Detector.Ball b = it.next();
                float bx = f[0] + b.x, by = f[1] + b.y;
                if (bx > bubbleX - rad && bx < bubbleX + bubbleSize + rad
                        && by > bubbleY - rad && by < bubbleY + bubbleSize + rad) it.remove();
            }
            Detector.Ball cue = null;
            for (Detector.Ball b : res.balls) if (b.cue) cue = b;
            if (cue == null) {
                prev = null;
                postDone(null, null, 0, 0, 1, false, false, true);
                return;
            }

            // wait until the balls stand still
            float[][] cur = new float[res.balls.size()][2];
            for (int i = 0; i < cur.length; i++) {
                cur[i][0] = res.balls.get(i).x;
                cur[i][1] = res.balls.get(i).y;
            }
            boolean stable = prev != null && prev.length == cur.length;
            if (stable) {
                for (float[] c : cur) {
                    boolean ok = false;
                    for (float[] p : prev) {
                        float dx = c[0] - p[0], dy = c[1] - p[1];
                        if (dx * dx + dy * dy < 2.5f * 2.5f) {
                            ok = true;
                            break;
                        }
                    }
                    if (!ok) {
                        stable = false;
                        break;
                    }
                }
            }
            prev = cur;
            if (!stable) {
                postDone(null, null, 0, 0, 1, false, false, true);
                return;
            }

            SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
            final int mode = sp.getInt("target", 0);
            final int cuePower = sp.getInt("power", 7714);
            final float pullFrac = sp.getInt("pull", 100) / 100f;
            final boolean ext = sp.getBoolean("extreme", true);
            final boolean ray = sp.getBoolean("ray", true);

            ArrayList<float[]> in = new ArrayList<>();
            int ci = 0;
            for (Detector.Ball b : res.balls) {
                if (b.cue) ci = in.size();
                in.add(new float[]{b.x / sc, b.y / sc, b.type});
            }

            // best shot: only recompute when the balls changed
            long key = mode * 1000003L + cuePower;
            for (float[] b : in) key = key * 31 + Math.round(b[0] / 3f) * 1000L + Math.round(b[1] / 3f);
            if (key != lastKey || lastBest == null) {
                lastBest = Advisor.best(in, ci, mode, cuePower);
                lastKey = key;
            }

            // the aim the game currently shows, if any
            Physics.Out aim = null;
            if (res.ghost != null) {
                float dx = res.ghost.x - cue.x, dy = res.ghost.y - cue.y;
                float len = (float) Math.sqrt(dx * dx + dy * dy);
                if (len > 4f) {
                    aim = Physics.run(in, ci, dx / len, dy / len, cuePower * pullFrac);
                }
            }
            postDone(aim, lastBest, f[0], f[1], sc, ext, ray, false);
        } catch (Throwable t) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    toast("Analysis error");
                }
            });
            postDone(null, null, 0, 0, 1, false, false, true);
        }
    }

    @Override
    public void onDestroy() {
        live = false;
        h.removeCallbacksAndMessages(null);
        try {
            if (bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        try {
            if (overlay != null) wm.removeView(overlay);
        } catch (Exception ignored) {
        }
        try {
            if (vd != null) vd.release();
            if (reader != null) reader.close();
            if (mp != null) mp.stop();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
