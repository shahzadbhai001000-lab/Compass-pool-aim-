package com.poolaim.lab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;

/** Transparent full-screen layer that draws the aim result on top of the game. */
public class AimOverlay extends View {

    private Physics.Out aim;          // result of the aim the game currently shows (may be null)
    private Advisor.Shot best;        // best shot found by the app (may be null)
    private float ox, oy, sc;
    private boolean extreme, showRay;
    private boolean has;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float dp;

    public AimOverlay(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setColor(0xFFFFFFFF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(16f * dp);
    }

    public void show(Physics.Out aimOut, Advisor.Shot bestShot, float originX, float originY,
                     float scale, boolean extremeMode, boolean ray) {
        aim = aimOut;
        best = bestShot;
        ox = originX;
        oy = originY;
        sc = scale;
        extreme = extremeMode;
        showRay = ray;
        has = true;
        invalidate();
    }

    public void clear() {
        has = false;
        aim = null;
        best = null;
        invalidate();
    }

    public boolean hasResult() {
        return has;
    }

    private float sx(float x) {
        return ox + x * sc;
    }

    private float sy(float y) {
        return oy + y * sc;
    }

    private void polyline(Canvas c, ArrayList<float[]> pts, int color, float width, boolean dashed) {
        if (pts.size() < 2) return;
        path.reset();
        path.moveTo(sx(pts.get(0)[0]), sy(pts.get(0)[1]));
        for (int i = 1; i < pts.size(); i++) path.lineTo(sx(pts.get(i)[0]), sy(pts.get(i)[1]));
        stroke.setColor(color);
        stroke.setStrokeWidth(width * dp);
        stroke.setPathEffect(dashed ? new DashPathEffect(new float[]{10f * dp, 8f * dp}, 0f) : null);
        c.drawPath(path, stroke);
        stroke.setPathEffect(null);
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width * dp);
        stroke.setPathEffect(null);
        c.drawLine(sx(x1), sy(y1), sx(x2), sy(y2), stroke);
    }

    private void circle(Canvas c, float x, float y, float rad, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width * dp);
        stroke.setPathEffect(null);
        c.drawCircle(sx(x), sy(y), rad * sc, stroke);
    }

    @Override
    protected void onDraw(Canvas c) {
        // marker used to find out whether screen capture can see this layer
        fill.setColor(0xFFFF00FF);
        c.drawRect(2f * dp, 2f * dp, 12f * dp, 12f * dp, fill);

        if (!has) return;
        final float r = Physics.R;
        ArrayList<String> lines = new ArrayList<>();
        boolean bad = false;

        // ---- the player's current aim (only when the game shows an aim line)
        if (aim != null) {
            final Physics.Out o = aim;
            if (showRay) polyline(c, o.ray, 0xCC00E5FF, 1.6f, true);
            for (Physics.Body b : o.bodies) {
                if (b.type == 0) continue;
                boolean moved = b.path.size() > 2;
                if (moved) polyline(c, b.path, extreme ? 0xAAFFD54F : 0xFFFFD54F, extreme ? 1.8f : 2.6f, false);
            }
            for (Physics.Body b : o.bodies) {
                if (b.type == 0) polyline(c, b.path, 0xFFFFFFFF, 3f, false);
            }
            for (Physics.Body b : o.bodies) {
                if (b.out) continue;
                boolean moved = b.path.size() > 2;
                if (b.type == 0 || (extreme && moved)) {
                    float[] last = b.path.get(b.path.size() - 1);
                    stroke.setColor(b.type == 0 ? 0xFFFFFFFF : 0xFFFF5252);
                    stroke.setStrokeWidth(2.2f * dp);
                    float px = sx(last[0]), py = sy(last[1]), rr = r * sc;
                    c.drawCircle(px, py, rr, stroke);
                    c.drawLine(px - rr * 0.6f, py - rr * 0.6f, px + rr * 0.6f, py + rr * 0.6f, stroke);
                    c.drawLine(px - rr * 0.6f, py + rr * 0.6f, px + rr * 0.6f, py - rr * 0.6f, stroke);
                }
            }
            if (o.firstType >= 0) circle(c, o.hitX, o.hitY, r, 0xFFFFFFFF, 2f);
            for (Physics.Body b : o.bodies) {
                if (!b.out) continue;
                boolean isBad = b.type == 0 || b.type == 1;
                circle(c, b.startX, b.startY, r * 1.45f, isBad ? 0xFFFF1744 : 0xFF00E676, 4f);
            }
            if (o.cuePot) lines.add("WARNING: CUE BALL WILL POT");
            if (o.blackPot) lines.add("WARNING: BLACK BALL WILL POT");
            bad = o.cuePot || o.blackPot;
            lines.add("Your aim: balls going in " + o.othersPotted);
        }

        // ---- the best shot the app found by itself
        if (best != null && best.found) {
            final int green = 0xFF00E676;
            line(c, best.cx, best.cy, best.gx, best.gy, green, 4f);
            circle(c, best.gx, best.gy, r, green, 3f);
            if (best.bank) {
                line(c, best.tx, best.ty, best.bx, best.by, green, 3f);
                line(c, best.bx, best.by, best.px, best.py, green, 3f);
            } else {
                line(c, best.tx, best.ty, best.px, best.py, green, 3f);
            }
            circle(c, best.tx, best.ty, r * 1.5f, green, 4f);
            int pct = Math.round(best.pull * 100f);
            lines.add((best.bank ? "BEST SHOT (BANK): pull " : "BEST SHOT: pull ") + pct
                    + "%  (balls in: " + best.out.othersPotted + ")");
        } else if (best != null) {
            lines.add("No safe pot found");
        }

        if (lines.isEmpty()) return;
        float lh = text.getTextSize() * 1.3f;
        float w = 0f;
        for (String s : lines) w = Math.max(w, text.measureText(s));
        float padX = 12f * dp, padY = 6f * dp;
        float left = (getWidth() - w) / 2f - padX;
        float top = 6f * dp;
        RectF rect = new RectF(left, top, left + w + 2 * padX, top + lh * lines.size() + 2 * padY);
        fill.setColor(bad ? 0xF0C62828 : 0xE02E7D32);
        c.drawRoundRect(rect, 12f * dp, 12f * dp, fill);
        float ty = top + padY + text.getTextSize();
        for (String s : lines) {
            c.drawText(s, (getWidth() - text.measureText(s)) / 2f, ty, text);
            ty += lh;
        }
    }
}
