package com.poolaim.lab;

import java.util.ArrayList;

/** Finds the balls in a screenshot of the felt. Pure Java, no Android classes. */
public final class Detector {

    public static final class Ball {
        public float x, y;
        public int num;          // 0 = cue ball, 8 = black, others are only rough guesses
        public int type;         // 0 cue, 1 black, 2 solid, 3 stripe
        public boolean cue, stripe, black;
    }

    public static final class Result {
        public final ArrayList<Ball> balls = new ArrayList<>();
        public Ball ghost;       // the grey "ghost ball" the game draws at the end of its aim line
        public int cores;
    }

    /** Finds the playing felt inside a full screenshot. Returns {left, top, right, bottom} or null. */
    public static int[] findFelt(int[] px, int W, int H) {
        final int step = 4;
        int cw = W / step, ch = H / step;
        int[] col = new int[cw], row = new int[ch];
        for (int y = 0; y < ch; y++) {
            for (int x = 0; x < cw; x++) {
                int p = px[(y * step) * W + x * step];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (b > 70 && g * 100 > b * 72 && r * 100 < b * 55) {
                    col[x]++;
                    row[y]++;
                }
            }
        }
        int maxC = 0, maxR = 0;
        for (int v : col) maxC = Math.max(maxC, v);
        for (int v : row) maxR = Math.max(maxR, v);
        if (maxC < 20 || maxR < 20) return null;
        int l = -1, rr = -1, t = -1, bt = -1;
        for (int x = 0; x < cw; x++) if (col[x] > 0.35 * maxC) { if (l < 0) l = x; rr = x; }
        for (int y = 0; y < ch; y++) if (row[y] > 0.35 * maxR) { if (t < 0) t = y; bt = y; }
        if (l < 0 || t < 0) return null;
        int left = l * step, right = (rr + 1) * step, top = t * step, bottom = (bt + 1) * step;
        int inset = Math.round(0.0254f * (right - left));
        left += inset;
        right -= inset;
        top += inset;
        bottom -= inset;
        if (right - left < 200 || bottom - top < 100) return null;
        return new int[]{left, top, right, bottom};
    }

    /**
     * px   = ARGB pixels of the felt rectangle (w x h)
     * r    = ball radius in pixels
     * sens = colour difference from the felt needed to count as "not felt" (about 55)
     */
    public static Result detect(int[] px, int w, int h, float r, float sens) {
        Result res = new Result();
        double[][] c = fitFelt(px, w, h);
        final int BIG = 1 << 28;
        final double s2 = sens * sens;
        int[] d = new int[w * h];
        double[] f = new double[6];
        for (int y = 0; y < h; y++) {
            double v = 2.0 * y / h - 1;
            for (int x = 0; x < w; x++) {
                double u = 2.0 * x / w - 1;
                feats(f, u, v);
                int p = px[y * w + x];
                double dr = ((p >> 16) & 255) - dot(c[0], f);
                double dg = ((p >> 8) & 255) - dot(c[1], f);
                double db = (p & 255) - dot(c[2], f);
                d[y * w + x] = (dr * dr + dg * dg + db * db > s2) ? BIG : 0;
            }
        }
        chamfer(d, w, h);

        final int thr = Math.round(0.7f * r * 3f);
        boolean[] seen = new boolean[w * h];
        int[] queue = new int[w * h];
        ArrayList<float[]> cores = new ArrayList<>();
        for (int i = 0; i < w * h; i++) {
            if (seen[i] || d[i] < thr) continue;
            int qh = 0, qt = 0;
            queue[qt++] = i;
            seen[i] = true;
            double sx = 0, sy = 0;
            int area = 0;
            while (qh < qt) {
                int p = queue[qh++];
                int py = p / w, pxx = p - py * w;
                sx += pxx;
                sy += py;
                area++;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = py + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = pxx + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (!seen[q] && d[q] >= thr) {
                            seen[q] = true;
                            queue[qt++] = q;
                        }
                    }
                }
            }
            res.cores++;
            float cx = (float) (sx / area), cy = (float) (sy / area);
            if (area < 3) continue;
            if (area > Math.PI * r * r * 1.2) continue;
            float m = 0.6f * r;
            if (cx < m || cy < m || cx > w - m || cy > h - m) continue;
            cores.add(new float[]{cx, cy, area});
        }

        // merge cores that belong to the same ball
        boolean merged = true;
        while (merged) {
            merged = false;
            outer:
            for (int i = 0; i < cores.size(); i++) {
                for (int j = i + 1; j < cores.size(); j++) {
                    float[] a = cores.get(i), b = cores.get(j);
                    float dx = a[0] - b[0], dy = a[1] - b[1];
                    if (dx * dx + dy * dy < r * r) {
                        float t = a[2] + b[2];
                        a[0] = (a[0] * a[2] + b[0] * b[2]) / t;
                        a[1] = (a[1] * a[2] + b[1] * b[2]) / t;
                        a[2] = t;
                        cores.remove(j);
                        merged = true;
                        break outer;
                    }
                }
            }
        }

        Ball cue = null;
        float cueScore = 0;
        for (float[] k : cores) {
            Ball b = new Ball();
            b.x = k[0];
            b.y = k[1];
            float[] info = classify(px, w, h, b, r);
            // info: kind (0 ignore,1 cue,2 black,3 solid,4 stripe), cls, ringWhite
            int kind = (int) info[0];
            if (kind == 0) continue;
            if (kind == 5) {
                if (res.ghost == null) {
                    b.type = 4;
                    res.ghost = b;
                }
                continue;
            }
            if (kind == 1) {
                b.cue = true;
                b.type = 0;
                b.num = 0;
                if (info[2] > cueScore) {
                    if (cue != null) res.balls.remove(cue);
                    cue = b;
                    cueScore = info[2];
                    res.balls.add(b);
                }
                continue;
            }
            if (kind == 2) {
                b.black = true;
                b.type = 1;
                b.num = 8;
            } else if (kind == 3) {
                b.type = 2;
                b.num = (int) info[1];
            } else {
                b.type = 3;
                b.stripe = true;
                b.num = (int) info[1] + 8;
            }
            res.balls.add(b);
        }
        return res;
    }

    // returns {kind, class, ringWhiteFraction}
    private static float[] classify(int[] px, int w, int h, Ball b, float r) {
        int cnt = 0, white = 0, dark = 0, colored = 0, ringCnt = 0, ringWhite = 0;
        double sumS = 0, sumV = 0;
        int[] cls = new int[8];
        int x0 = Math.max(0, (int) (b.x - r)), x1 = Math.min(w - 1, (int) (b.x + r));
        int y0 = Math.max(0, (int) (b.y - r)), y1 = Math.min(h - 1, (int) (b.y + r));
        float lim = 0.9f * r;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                float dx = x - b.x, dy = y - b.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist > lim) continue;
                int p = px[y * w + x];
                int R = (p >> 16) & 255, G = (p >> 8) & 255, B = p & 255;
                int mx = Math.max(R, Math.max(G, B)), mn = Math.min(R, Math.min(G, B));
                float v = mx / 255f;
                float s = mx == 0 ? 0 : (mx - mn) / (float) mx;
                cnt++;
                sumS += s;
                sumV += v;
                boolean isWhite = v >= 0.72f && s <= 0.28f;
                if (v < 0.25f) dark++;
                if (dist >= 0.5f * r) {
                    ringCnt++;
                    if (isWhite) ringWhite++;
                }
                if (isWhite) {
                    white++;
                } else if (s > 0.35f && v >= 0.25f) {
                    colored++;
                    cls[hueClass(R, G, B, mx, mn, v)]++;
                }
            }
        }
        if (cnt == 0) return new float[]{0, 0, 0};
        float ringW = ringCnt == 0 ? 0 : ringWhite / (float) ringCnt;
        float darkF = dark / (float) cnt;
        float colF = colored / (float) cnt;
        if (ringW >= 0.6f && darkF < 0.1f && colF < 0.1f && sumV / cnt > 0.78) return new float[]{1, 0, ringW};
        if (darkF >= 0.35f) return new float[]{2, 8, ringW};
        if (colF < 0.15f) {
            double mS = sumS / cnt, mV = sumV / cnt;
            if (ringW < 0.6f && darkF < 0.1f && mS < 0.16 && mV > 0.5 && mV < 0.9)
                return new float[]{5, 0, ringW};          // grey ghost ball
            return new float[]{0, 0, 0};
        }
        int best = 1;
        for (int i = 1; i <= 7; i++) if (cls[i] > cls[best]) best = i;
        return new float[]{ringW >= 0.18f ? 4 : 3, best, ringW};
    }

    private static int hueClass(int R, int G, int B, int mx, int mn, float v) {
        float hue;
        float dl = mx - mn;
        if (dl == 0) hue = 0;
        else if (mx == R) hue = 60f * (((G - B) / dl) % 6);
        else if (mx == G) hue = 60f * ((B - R) / dl + 2);
        else hue = 60f * ((R - G) / dl + 4);
        if (hue < 0) hue += 360;
        if (hue >= 38 && hue < 72) return 1;            // yellow
        if (hue >= 12 && hue < 38) return v < 0.55f ? 7 : 5; // orange / maroon
        if (hue < 12 || hue >= 340) return v < 0.55f ? 7 : 3; // red / maroon
        if (hue >= 72 && hue < 175) return 6;           // green
        if (hue >= 175 && hue < 255) return 2;          // blue
        return 4;                                       // purple
    }

    private static void chamfer(int[] d, int w, int h) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int v = d[i];
                if (v == 0) continue;
                int m = v;
                if (x > 0) m = Math.min(m, d[i - 1] + 3);
                if (y > 0) {
                    m = Math.min(m, d[i - w] + 3);
                    if (x > 0) m = Math.min(m, d[i - w - 1] + 4);
                    if (x < w - 1) m = Math.min(m, d[i - w + 1] + 4);
                }
                d[i] = m;
            }
        }
        for (int y = h - 1; y >= 0; y--) {
            for (int x = w - 1; x >= 0; x--) {
                int i = y * w + x;
                int v = d[i];
                if (v == 0) continue;
                int m = v;
                if (x < w - 1) m = Math.min(m, d[i + 1] + 3);
                if (y < h - 1) {
                    m = Math.min(m, d[i + w] + 3);
                    if (x < w - 1) m = Math.min(m, d[i + w + 1] + 4);
                    if (x > 0) m = Math.min(m, d[i + w - 1] + 4);
                }
                d[i] = m;
            }
        }
    }

    // ---- felt colour model: quadratic surface per channel, fitted robustly ----

    private static void feats(double[] f, double u, double v) {
        f[0] = 1;
        f[1] = u;
        f[2] = v;
        f[3] = u * u;
        f[4] = v * v;
        f[5] = u * v;
    }

    private static double dot(double[] a, double[] f) {
        return a[0] * f[0] + a[1] * f[1] + a[2] * f[2] + a[3] * f[3] + a[4] * f[4] + a[5] * f[5];
    }

    private static double[][] fitFelt(int[] px, int w, int h) {
        double[][] c = new double[3][6];
        double[] thr = {1e9, 70, 50, 40};
        double[] f = new double[6];
        for (int it = 0; it < thr.length; it++) {
            double[][] A = new double[6][6];
            double[][] B = new double[3][6];
            for (int y = 0; y < h; y += 3) {
                double v = 2.0 * y / h - 1;
                for (int x = 0; x < w; x += 3) {
                    double u = 2.0 * x / w - 1;
                    feats(f, u, v);
                    int p = px[y * w + x];
                    double r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                    if (it > 0) {
                        double dr = r - dot(c[0], f), dg = g - dot(c[1], f), db = b - dot(c[2], f);
                        if (Math.sqrt(dr * dr + dg * dg + db * db) > thr[it]) continue;
                    }
                    for (int i = 0; i < 6; i++) {
                        for (int j = 0; j < 6; j++) A[i][j] += f[i] * f[j];
                        B[0][i] += f[i] * r;
                        B[1][i] += f[i] * g;
                        B[2][i] += f[i] * b;
                    }
                }
            }
            for (int k = 0; k < 3; k++) c[k] = solve(A, B[k]);
        }
        return c;
    }

    private static double[] solve(double[][] A0, double[] b0) {
        int n = 6;
        double[][] a = new double[n][n + 1];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) a[i][j] = A0[i][j];
            a[i][i] += 1e-6;
            a[i][n] = b0[i];
        }
        for (int col = 0; col < n; col++) {
            int piv = col;
            for (int r = col + 1; r < n; r++) if (Math.abs(a[r][col]) > Math.abs(a[piv][col])) piv = r;
            double[] t = a[col];
            a[col] = a[piv];
            a[piv] = t;
            double div = a[col][col];
            if (Math.abs(div) < 1e-12) continue;
            for (int j = col; j <= n; j++) a[col][j] /= div;
            for (int r = 0; r < n; r++) {
                if (r == col) continue;
                double m = a[r][col];
                if (m == 0) continue;
                for (int j = col; j <= n; j++) a[r][j] -= m * a[col][j];
            }
        }
        double[] x = new double[n];
        for (int i = 0; i < n; i++) x[i] = a[i][n];
        return x;
    }
}
